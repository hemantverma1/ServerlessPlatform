#!/bin/bash

folderName=`date +"%m%d%Y%H%M"`
folderName="virtualVM"$folderName
cd /tmp
mkdir $folderName
cd $folderName
vagrant box add $folderName /home/jayant/Desktop/serverless.box > /tmp/VMbootup.log 2>&1
vagrant init $folderName >> /tmp/VMbootup.log 2>&1
cp /var/serverless/Vagrantfile .
cp /var/serverless/findAndWriteIP.sh .
sed -i -- "s/\$BOXNAME/${folderName}/g" Vagrantfile
vagrant up >> /tmp/VMbootup.log 2>&1
while [ ! -e IP.txt ]; do
	sleep $(( ( RANDOM % 5 )  + 1 ))
done
echo $folderName
cat IP.txt
