#!/bin/bash
docker kill $(docker ps -q) ; docker rm $(docker ps -q -f status=exited) ;
sudo -S pkill -f "machineAgent ${host}" < ~/.passwd
sudo -S pkill -f "ServerLCManager" < ~/.passwd
sudo -S pkill -f "serviceLCMgr" < ~/.passwd
sudo -S pkill -f "Monitoring" < ~/.passwd
sudo -S pkill -f "LoadBalancer" < ~/.passwd
sudo -S pkill -f "Log" < ~/.passwd
