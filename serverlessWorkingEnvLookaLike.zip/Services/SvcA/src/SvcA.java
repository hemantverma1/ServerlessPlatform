public class SvcA {
	public int func1(int a) throws Exception{
		java.lang.Thread.sleep(1000);
		return a+10;
	}
}
