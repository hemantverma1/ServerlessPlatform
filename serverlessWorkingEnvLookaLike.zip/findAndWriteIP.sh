#!/bin/bash

ifconfig eth1 | grep "inet addr" | sed -E 's/^.*addr:(.*) .*$/\1/g' | cut -f1 -d' ' > /vagrant/IP.txt
